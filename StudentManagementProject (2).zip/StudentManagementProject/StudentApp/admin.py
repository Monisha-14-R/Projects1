from django.contrib import admin

from StudentApp.models import City

# Register your models here.
admin.site.register(City)
